import T from './JFormContainer.vue'
let install = function (Vue) {
  Vue.component('JFormContainer',T);
}
export default { install };